﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OkvirZaSlika
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Okno_Klik(object sender, EventArgs e) {
            OpenFileDialog fDialog = new OpenFileDialog();
            fDialog.Filter = "Image Files(*.BMP; *.JPG; *.GIF)| *.BMP; *.JPG; *.GIF | All files(*.*) | *.*";

            if (fDialog.ShowDialog() == DialogResult.OK) {
                if (fDialog.CheckFileExists)
                    Slika.Image = new Image(fDialog.FileName);
            }
        }
    }
}
