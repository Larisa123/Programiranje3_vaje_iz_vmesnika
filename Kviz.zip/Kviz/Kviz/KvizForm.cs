﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kviz
{
    public partial class Kviz : Form {
        private Podokno kviz;
        private bool kazemoRezultate;
        private Rezultati rezultati;

        private static int trenutnoVprasanje;
        Dictionary<int, string> izbire;

        VprasanjaInOdgovori vprasanjaInOdgovori;

        RadioButton[] radioGumbi;
        public Kviz() {
            InitializeComponent();

            inicializirajPodokni();
            inicializirajOstaleLastnosti();
            ponastavi(); // nastavi prvo vprasanje
        }

        private void inicializirajPodokni() {
            rezultati = new Rezultati();
            this.PanelPodokna.Controls.Add(rezultati);

            kviz = new Podokno();
            this.PanelPodokna.Controls.Add(kviz);
        }

        private void inicializirajOstaleLastnosti() {
            vprasanjaInOdgovori = new VprasanjaInOdgovori();
            izbire = new Dictionary<int, string> ();

            radioGumbi = new RadioButton[] { kviz.RadioGumb1, kviz.RadioGumb2, kviz.RadioGumb3 };
        }

        private void novoVprasanje() {
            trenutnoVprasanje++;

            kviz.SkupinaVprasanje.Text = "Vprasanje " + trenutnoVprasanje.ToString() + ":";

            for (int i = 0; i < radioGumbi.Length; i++) {
                radioGumbi[i].Text = vprasanjaInOdgovori.Slovar[trenutnoVprasanje - 1][i+1];
            }
        }

        private void ponastavi() {
            // prikazi spet vprasanja
            trenutnoVprasanje = 0;
            kazemoRezultate = false;
            vprasanjaInOdgovori = new VprasanjaInOdgovori();
            izbire = new Dictionary<int, string>();

            novoVprasanje();
            kviz.BringToFront();

            GumbPotrdi.Text = "Potrdi";
        }

        private void shraniIzbiro() {
            string vrednost = kviz.SkupinaVprasanje.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked).Text;

            if (izbire.ContainsKey(trenutnoVprasanje))
                izbire[trenutnoVprasanje] = vrednost;
            else
                izbire.Add(trenutnoVprasanje, vrednost);
        }

        private void prikaziRezultate() {
            kazemoRezultate = true;
            string rezultat = "";
            string vprasanje;
            foreach (KeyValuePair<int, string> izbira in izbire) {
                vprasanje = vprasanjaInOdgovori.Slovar[izbira.Key-1][0];
                rezultat += "Na " + vprasanje.ToLower() + " ste odgovorili z : " + izbira.Value;
                rezultat += "\n";
            }
            rezultati.NapisRezultati.Text = rezultat;
            GumbPotrdi.Text = "Ponovno";
            rezultati.BringToFront();
        }

        

        private void GumbPotrdi_Click(object sender, EventArgs e){
            if (kazemoRezultate) {
                ponastavi();
                return;
            }

            // Vzemimo rezultat:
            shraniIzbiro();

            if (trenutnoVprasanje < VprasanjaInOdgovori.SteviloVprasanj)
                novoVprasanje();
            else if (trenutnoVprasanje == VprasanjaInOdgovori.SteviloVprasanj)
                prikaziRezultate();
         
        }
    }

}
