﻿namespace Kviz
{
    partial class Podokno
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SkupinaVprasanje = new System.Windows.Forms.GroupBox();
            this.RadioGumb3 = new System.Windows.Forms.RadioButton();
            this.RadioGumb2 = new System.Windows.Forms.RadioButton();
            this.RadioGumb1 = new System.Windows.Forms.RadioButton();
            this.SkupinaVprasanje.SuspendLayout();
            this.SuspendLayout();
            // 
            // SkupinaVprasanje
            // 
            this.SkupinaVprasanje.Controls.Add(this.RadioGumb3);
            this.SkupinaVprasanje.Controls.Add(this.RadioGumb2);
            this.SkupinaVprasanje.Controls.Add(this.RadioGumb1);
            this.SkupinaVprasanje.Location = new System.Drawing.Point(18, 17);
            this.SkupinaVprasanje.Name = "SkupinaVprasanje";
            this.SkupinaVprasanje.Size = new System.Drawing.Size(274, 95);
            this.SkupinaVprasanje.TabIndex = 2;
            this.SkupinaVprasanje.TabStop = false;
            this.SkupinaVprasanje.Text = "Vprašanje ";
            // 
            // RadioGumb3
            // 
            this.RadioGumb3.AutoSize = true;
            this.RadioGumb3.Location = new System.Drawing.Point(6, 65);
            this.RadioGumb3.Name = "RadioGumb3";
            this.RadioGumb3.Size = new System.Drawing.Size(59, 17);
            this.RadioGumb3.TabIndex = 5;
            this.RadioGumb3.TabStop = true;
            this.RadioGumb3.Text = "Izbira 3";
            this.RadioGumb3.UseVisualStyleBackColor = true;
            // 
            // RadioGumb2
            // 
            this.RadioGumb2.AutoSize = true;
            this.RadioGumb2.Location = new System.Drawing.Point(6, 42);
            this.RadioGumb2.Name = "RadioGumb2";
            this.RadioGumb2.Size = new System.Drawing.Size(59, 17);
            this.RadioGumb2.TabIndex = 4;
            this.RadioGumb2.TabStop = true;
            this.RadioGumb2.Text = "Izbira 2";
            this.RadioGumb2.UseVisualStyleBackColor = true;
            // 
            // RadioGumb1
            // 
            this.RadioGumb1.AutoSize = true;
            this.RadioGumb1.Location = new System.Drawing.Point(6, 19);
            this.RadioGumb1.Name = "RadioGumb1";
            this.RadioGumb1.Size = new System.Drawing.Size(59, 17);
            this.RadioGumb1.TabIndex = 3;
            this.RadioGumb1.TabStop = true;
            this.RadioGumb1.Text = "Izbira 1";
            this.RadioGumb1.UseVisualStyleBackColor = true;
            // 
            // Podokno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.SkupinaVprasanje);
            this.Name = "Podokno";
            this.Size = new System.Drawing.Size(311, 134);
            this.SkupinaVprasanje.ResumeLayout(false);
            this.SkupinaVprasanje.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.GroupBox SkupinaVprasanje;
        public System.Windows.Forms.RadioButton RadioGumb3;
        public System.Windows.Forms.RadioButton RadioGumb2;
        public System.Windows.Forms.RadioButton RadioGumb1;
    }
}
