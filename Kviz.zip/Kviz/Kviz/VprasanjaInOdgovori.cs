﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kviz {
    /// <summary>
    /// Shranjuje slovar vprašanj in odgovorov.
    /// </summary>
    class VprasanjaInOdgovori {
        public Dictionary<int, string[]> Slovar;
        public static int SteviloVprasanj;

        public VprasanjaInOdgovori() {
            SteviloVprasanj = 3;

            Slovar = new Dictionary<int, string[]>();

            // tu lahko napisemo vprasanja in odgovore, če bi jih imeli več bi lahko brali tudi iz datoteke

            string[] vprasanja = new string[] {"Vprasanje1", "Vprasanje2", "Vprasanje3" };
            string[,] odgovori = new string[,] {{ "Izbira 1", "Izbira 2", "Izbira 3" },
                                                { "Izbira 1", "Izbira 2", "Izbira 3" },
                                                { "Izbira 1", "Izbira 2", "Izbira 3" }
                                                };

            string[] vrednost;
            for (int i = 0; i < vprasanja.Length; i++) {
                vrednost = new string[SteviloVprasanj + 1];
                vrednost[0] = vprasanja[i];
                for (int j = 1; j < SteviloVprasanj + 1; j++)  {
                    vrednost[j] = odgovori[i, j-1] + i.ToString(); // toliko da se malo razlikuje
                }
                Slovar[i] = vrednost;
            }
        }
    }
}
