﻿namespace WindowsFormsApp1
{
    partial class Risanje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RisalnaPovrsina = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.RisalnaPovrsina)).BeginInit();
            this.SuspendLayout();
            // 
            // RisalnaPovrsina
            // 
            this.RisalnaPovrsina.Location = new System.Drawing.Point(0, -2);
            this.RisalnaPovrsina.Name = "RisalnaPovrsina";
            this.RisalnaPovrsina.Size = new System.Drawing.Size(486, 332);
            this.RisalnaPovrsina.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.RisalnaPovrsina.TabIndex = 0;
            this.RisalnaPovrsina.TabStop = false;
            this.RisalnaPovrsina.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.RisalnaPovrsina_MouseDoubleClick);
            this.RisalnaPovrsina.MouseDown += new System.Windows.Forms.MouseEventHandler(this.RisalnaPovrsina_MouseDown);
            this.RisalnaPovrsina.MouseMove += new System.Windows.Forms.MouseEventHandler(this.RisalnaPovrsina_MouseMove);
            this.RisalnaPovrsina.MouseUp += new System.Windows.Forms.MouseEventHandler(this.RisalnaPovrsina_MouseUp);
            // 
            // Risanje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 329);
            this.Controls.Add(this.RisalnaPovrsina);
            this.Name = "Risanje";
            this.Text = "Risalec";
            ((System.ComponentModel.ISupportInitialize)(this.RisalnaPovrsina)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox RisalnaPovrsina;
    }
}

