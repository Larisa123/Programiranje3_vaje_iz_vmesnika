﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Studenti
{
    class Student {
        public string Ime;
        public string Priimek;
        public string Spol; // Z ali M
        public string DatumRojstva;

        public Student(string ime, string priimek, string spol, string datum) {
            this.Ime = ime;
            this.Priimek = priimek;
            this.Spol = spol;
            this.DatumRojstva = datum;
        }

        override public string ToString() { return this.Ime + " " + this.Priimek; }
    }
}
