﻿namespace Studenti
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SeznamStudentov = new System.Windows.Forms.ListBox();
            this.NapisIzbranStudent = new System.Windows.Forms.Label();
            this.NapisSpol2 = new System.Windows.Forms.Label();
            this.napisDatum2 = new System.Windows.Forms.Label();
            this.napisNavodilo = new System.Windows.Forms.Label();
            this.napisIme = new System.Windows.Forms.Label();
            this.napisPriimek = new System.Windows.Forms.Label();
            this.NapisSpol = new System.Windows.Forms.Label();
            this.NapisDatumRojstva = new System.Windows.Forms.Label();
            this.GumbVnos = new System.Windows.Forms.Button();
            this.napisIzbranImePriimek = new System.Windows.Forms.Label();
            this.NapisIzbranSpol = new System.Windows.Forms.Label();
            this.NapisIzbranDatum = new System.Windows.Forms.Label();
            this.ZbiralecDatuma_DRojstva = new System.Windows.Forms.DateTimePicker();
            this.RadioGumbZenski = new System.Windows.Forms.RadioButton();
            this.RadioGumbMoski = new System.Windows.Forms.RadioButton();
            this.VnosnoPoljeIme = new System.Windows.Forms.TextBox();
            this.VnosnoPoljePriimek = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // SeznamStudentov
            // 
            this.SeznamStudentov.FormattingEnabled = true;
            this.SeznamStudentov.Location = new System.Drawing.Point(27, 41);
            this.SeznamStudentov.Name = "SeznamStudentov";
            this.SeznamStudentov.Size = new System.Drawing.Size(221, 173);
            this.SeznamStudentov.TabIndex = 0;
            this.SeznamStudentov.SelectedIndexChanged += new System.EventHandler(this.SeznamStudentov_SelectedIndexChanged);
            // 
            // NapisIzbranStudent
            // 
            this.NapisIzbranStudent.AutoSize = true;
            this.NapisIzbranStudent.Location = new System.Drawing.Point(27, 221);
            this.NapisIzbranStudent.Name = "NapisIzbranStudent";
            this.NapisIzbranStudent.Size = new System.Drawing.Size(98, 13);
            this.NapisIzbranStudent.TabIndex = 1;
            this.NapisIzbranStudent.Text = "Izbrali ste študenta:";
            this.NapisIzbranStudent.Visible = false;
            // 
            // NapisSpol2
            // 
            this.NapisSpol2.AutoSize = true;
            this.NapisSpol2.Location = new System.Drawing.Point(27, 243);
            this.NapisSpol2.Name = "NapisSpol2";
            this.NapisSpol2.Size = new System.Drawing.Size(31, 13);
            this.NapisSpol2.TabIndex = 2;
            this.NapisSpol2.Text = "Spol:";
            this.NapisSpol2.Visible = false;
            // 
            // napisDatum2
            // 
            this.napisDatum2.AutoSize = true;
            this.napisDatum2.Location = new System.Drawing.Point(27, 265);
            this.napisDatum2.Name = "napisDatum2";
            this.napisDatum2.Size = new System.Drawing.Size(75, 13);
            this.napisDatum2.TabIndex = 3;
            this.napisDatum2.Text = "Datum rojstva:";
            this.napisDatum2.Visible = false;
            // 
            // napisNavodilo
            // 
            this.napisNavodilo.AutoSize = true;
            this.napisNavodilo.Location = new System.Drawing.Point(280, 41);
            this.napisNavodilo.Name = "napisNavodilo";
            this.napisNavodilo.Size = new System.Drawing.Size(80, 13);
            this.napisNavodilo.TabIndex = 4;
            this.napisNavodilo.Text = "Vnesi študenta:";
            // 
            // napisIme
            // 
            this.napisIme.AutoSize = true;
            this.napisIme.Location = new System.Drawing.Point(280, 68);
            this.napisIme.Name = "napisIme";
            this.napisIme.Size = new System.Drawing.Size(27, 13);
            this.napisIme.TabIndex = 5;
            this.napisIme.Text = "Ime:";
            // 
            // napisPriimek
            // 
            this.napisPriimek.AutoSize = true;
            this.napisPriimek.Location = new System.Drawing.Point(280, 93);
            this.napisPriimek.Name = "napisPriimek";
            this.napisPriimek.Size = new System.Drawing.Size(44, 13);
            this.napisPriimek.TabIndex = 6;
            this.napisPriimek.Text = "Priimek:";
            // 
            // NapisSpol
            // 
            this.NapisSpol.AutoSize = true;
            this.NapisSpol.Location = new System.Drawing.Point(280, 120);
            this.NapisSpol.Name = "NapisSpol";
            this.NapisSpol.Size = new System.Drawing.Size(31, 13);
            this.NapisSpol.TabIndex = 7;
            this.NapisSpol.Text = "Spol:";
            // 
            // NapisDatumRojstva
            // 
            this.NapisDatumRojstva.AutoSize = true;
            this.NapisDatumRojstva.Location = new System.Drawing.Point(280, 145);
            this.NapisDatumRojstva.Name = "NapisDatumRojstva";
            this.NapisDatumRojstva.Size = new System.Drawing.Size(75, 13);
            this.NapisDatumRojstva.TabIndex = 8;
            this.NapisDatumRojstva.Text = "Datum rojstva:";
            // 
            // GumbVnos
            // 
            this.GumbVnos.Location = new System.Drawing.Point(361, 191);
            this.GumbVnos.Name = "GumbVnos";
            this.GumbVnos.Size = new System.Drawing.Size(106, 23);
            this.GumbVnos.TabIndex = 9;
            this.GumbVnos.Text = "Vnesi";
            this.GumbVnos.UseVisualStyleBackColor = true;
            this.GumbVnos.Click += new System.EventHandler(this.GumbVnos_Click);
            // 
            // napisIzbranImePriimek
            // 
            this.napisIzbranImePriimek.AutoSize = true;
            this.napisIzbranImePriimek.Location = new System.Drawing.Point(132, 221);
            this.napisIzbranImePriimek.Name = "napisIzbranImePriimek";
            this.napisIzbranImePriimek.Size = new System.Drawing.Size(72, 13);
            this.napisIzbranImePriimek.TabIndex = 10;
            this.napisIzbranImePriimek.Text = "Ime in Priimek";
            this.napisIzbranImePriimek.Visible = false;
            // 
            // NapisIzbranSpol
            // 
            this.NapisIzbranSpol.AutoSize = true;
            this.NapisIzbranSpol.Location = new System.Drawing.Point(132, 243);
            this.NapisIzbranSpol.Name = "NapisIzbranSpol";
            this.NapisIzbranSpol.Size = new System.Drawing.Size(78, 13);
            this.NapisIzbranSpol.TabIndex = 11;
            this.NapisIzbranSpol.Text = "Ženski / Moški";
            this.NapisIzbranSpol.Visible = false;
            // 
            // NapisIzbranDatum
            // 
            this.NapisIzbranDatum.AutoSize = true;
            this.NapisIzbranDatum.Location = new System.Drawing.Point(132, 265);
            this.NapisIzbranDatum.Name = "NapisIzbranDatum";
            this.NapisIzbranDatum.Size = new System.Drawing.Size(65, 13);
            this.NapisIzbranDatum.TabIndex = 12;
            this.NapisIzbranDatum.Text = "00/00/0000";
            this.NapisIzbranDatum.Visible = false;
            // 
            // ZbiralecDatuma_DRojstva
            // 
            this.ZbiralecDatuma_DRojstva.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ZbiralecDatuma_DRojstva.Location = new System.Drawing.Point(361, 145);
            this.ZbiralecDatuma_DRojstva.Name = "ZbiralecDatuma_DRojstva";
            this.ZbiralecDatuma_DRojstva.Size = new System.Drawing.Size(106, 20);
            this.ZbiralecDatuma_DRojstva.TabIndex = 13;
            // 
            // RadioGumbZenski
            // 
            this.RadioGumbZenski.AutoSize = true;
            this.RadioGumbZenski.Location = new System.Drawing.Point(371, 115);
            this.RadioGumbZenski.Name = "RadioGumbZenski";
            this.RadioGumbZenski.Size = new System.Drawing.Size(32, 17);
            this.RadioGumbZenski.TabIndex = 14;
            this.RadioGumbZenski.TabStop = true;
            this.RadioGumbZenski.Text = "Ž";
            this.RadioGumbZenski.UseVisualStyleBackColor = true;
            // 
            // RadioGumbMoski
            // 
            this.RadioGumbMoski.AutoSize = true;
            this.RadioGumbMoski.Location = new System.Drawing.Point(426, 115);
            this.RadioGumbMoski.Name = "RadioGumbMoski";
            this.RadioGumbMoski.Size = new System.Drawing.Size(34, 17);
            this.RadioGumbMoski.TabIndex = 15;
            this.RadioGumbMoski.TabStop = true;
            this.RadioGumbMoski.Text = "M";
            this.RadioGumbMoski.UseVisualStyleBackColor = true;
            // 
            // VnosnoPoljeIme
            // 
            this.VnosnoPoljeIme.Location = new System.Drawing.Point(361, 65);
            this.VnosnoPoljeIme.Name = "VnosnoPoljeIme";
            this.VnosnoPoljeIme.Size = new System.Drawing.Size(106, 20);
            this.VnosnoPoljeIme.TabIndex = 16;
            // 
            // VnosnoPoljePriimek
            // 
            this.VnosnoPoljePriimek.Location = new System.Drawing.Point(361, 90);
            this.VnosnoPoljePriimek.Name = "VnosnoPoljePriimek";
            this.VnosnoPoljePriimek.Size = new System.Drawing.Size(106, 20);
            this.VnosnoPoljePriimek.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 302);
            this.Controls.Add(this.VnosnoPoljePriimek);
            this.Controls.Add(this.VnosnoPoljeIme);
            this.Controls.Add(this.RadioGumbMoski);
            this.Controls.Add(this.RadioGumbZenski);
            this.Controls.Add(this.ZbiralecDatuma_DRojstva);
            this.Controls.Add(this.NapisIzbranDatum);
            this.Controls.Add(this.NapisIzbranSpol);
            this.Controls.Add(this.napisIzbranImePriimek);
            this.Controls.Add(this.GumbVnos);
            this.Controls.Add(this.NapisDatumRojstva);
            this.Controls.Add(this.NapisSpol);
            this.Controls.Add(this.napisPriimek);
            this.Controls.Add(this.napisIme);
            this.Controls.Add(this.napisNavodilo);
            this.Controls.Add(this.napisDatum2);
            this.Controls.Add(this.NapisSpol2);
            this.Controls.Add(this.NapisIzbranStudent);
            this.Controls.Add(this.SeznamStudentov);
            this.Name = "Form1";
            this.Text = "Studenti";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox SeznamStudentov;
        private System.Windows.Forms.Label NapisIzbranStudent;
        private System.Windows.Forms.Label NapisSpol2;
        private System.Windows.Forms.Label napisDatum2;
        private System.Windows.Forms.Label napisNavodilo;
        private System.Windows.Forms.Label napisIme;
        private System.Windows.Forms.Label napisPriimek;
        private System.Windows.Forms.Label NapisSpol;
        private System.Windows.Forms.Label NapisDatumRojstva;
        private System.Windows.Forms.Button GumbVnos;
        private System.Windows.Forms.Label napisIzbranImePriimek;
        private System.Windows.Forms.Label NapisIzbranSpol;
        private System.Windows.Forms.Label NapisIzbranDatum;
        private System.Windows.Forms.DateTimePicker ZbiralecDatuma_DRojstva;
        private System.Windows.Forms.RadioButton RadioGumbZenski;
        private System.Windows.Forms.RadioButton RadioGumbMoski;
        private System.Windows.Forms.TextBox VnosnoPoljeIme;
        private System.Windows.Forms.TextBox VnosnoPoljePriimek;
    }
}

