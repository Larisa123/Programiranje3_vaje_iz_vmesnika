﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studenti
{
    public partial class Form1 : Form {
        private Label[] skritiNapisi;

        public Form1() {
            InitializeComponent();

            skritiNapisi = new Label[] {napisIzbranImePriimek, NapisIzbranStudent, NapisIzbranDatum, NapisIzbranSpol, napisDatum2, NapisSpol2};
        }

        private void GumbVnos_Click(object sender, EventArgs e) {
            DodajStudenta();
        }

        private void DodajStudenta() {
            string spol = (RadioGumbZenski.Checked) ? "Ž" : "M";
            string datum = ZbiralecDatuma_DRojstva.Value.ToShortDateString();
            Student student = new Student(VnosnoPoljeIme.Text, VnosnoPoljePriimek.Text, spol, datum);
            SeznamStudentov.Items.Add(student);
        }

        private void SeznamStudentov_SelectedIndexChanged(object sender, EventArgs e) {
            PrikaziIzbranegaStudenta();
        }

        private void PrikaziIzbranegaStudenta() {
            Student izbranStudent = (Student)SeznamStudentov.SelectedItem;
            napisIzbranImePriimek.Text = izbranStudent.ToString();
            NapisIzbranDatum.Text = izbranStudent.DatumRojstva;
            NapisIzbranSpol.Text = izbranStudent.Spol;

            PrikaziNapise(true);
        }

        private void PrikaziNapise(bool prikazi) {
            foreach (Label napis in skritiNapisi)
                napis.Visible = prikazi;
        }
    }
}
