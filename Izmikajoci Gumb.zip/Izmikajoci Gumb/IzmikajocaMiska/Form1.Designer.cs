﻿namespace IzmikajocaMiska
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.GumbPremikajoci = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // GumbPremikajoci
            // 
            this.GumbPremikajoci.Location = new System.Drawing.Point(131, 106);
            this.GumbPremikajoci.Name = "GumbPremikajoci";
            this.GumbPremikajoci.Size = new System.Drawing.Size(75, 23);
            this.GumbPremikajoci.TabIndex = 0;
            this.GumbPremikajoci.Text = "Klikni me";
            this.GumbPremikajoci.UseVisualStyleBackColor = true;
            this.GumbPremikajoci.Click += new System.EventHandler(this.GumbPremikajoci_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.GumbPremikajoci);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button GumbPremikajoci;
    }
}

