﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IzmikajocaMiska
{
    public partial class Form1 : Form {
        Random randGenerator;
        public Form1() {
            randGenerator = new Random();
            InitializeComponent();
        }

        private void GumbPremikajoci_Click(object sender, EventArgs e) {
            premakniGumb();
        }

        private void premakniGumb() {
            // gumb ima anchor v (0, 0) - levi kot zgoraj, zakaj torej gre z tak definirano lokacijo včasih ven?

            int randomX = randGenerator.Next(0, this.Size.Width - GumbPremikajoci.Size.Width);
            int randomY = randGenerator.Next(0, this.Size.Height - GumbPremikajoci.Size.Height);
            GumbPremikajoci.Location = new Point(randomX, randomY);
        }
    }
}
