﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Aplikacija riše ob držanju levega gumba miške in zbriše površino ob
    /// dvojnem kliku. 
    /// Ideja implementacije: shranjujemo stanje miške (gor/dol) in se glede
    /// na to stanje odločamo, ali ob premikih miške rišemo ali ne.
    /// </summary>
    public partial class Risanje : Form {
        private Miska miska;
        private Point zadnjaLokacijaMiske;

        private Graphics risalo;
        private Pen pisalo;

        public Risanje() {
            InitializeComponent();

            miska = Miska.Gor; // na začetku ne pritiskamo na levi gumb
            zadnjaLokacijaMiske = new Point(0, 0);

            risalo = RisalnaPovrsina.CreateGraphics();
            pisalo = new Pen(Color.DeepSkyBlue);
        }

        private void RisalnaPovrsina_MouseDown(object sender, MouseEventArgs e) {
            miska = Miska.Dol;
            zadnjaLokacijaMiske = e.Location;
        }

        private void RisalnaPovrsina_MouseUp(object sender, MouseEventArgs e) {
            miska = Miska.Gor;
        }

        private void RisalnaPovrsina_MouseMove(object sender, MouseEventArgs e) {
            if (miska == Miska.Dol) {
                risalo.DrawLine(pisalo, zadnjaLokacijaMiske, e.Location);
                zadnjaLokacijaMiske = e.Location;
            }
        }

        private void RisalnaPovrsina_MouseDoubleClick(object sender, MouseEventArgs e) {
            risalo.Clear(this.BackColor);
        }
    }

    enum Miska { Dol, Gor }
}
